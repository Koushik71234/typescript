//all elements needed are here
const resultElement = document.querySelector(".result")! as HTMLParagraphElement;
const liveResult = document.querySelector(".live-result")! as HTMLParagraphElement;
const operatorsButton = document.querySelectorAll(".btn")! as NodeListOf<HTMLDivElement>;
